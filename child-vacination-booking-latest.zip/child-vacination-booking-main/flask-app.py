import sqlite3
from flask import Flask, render_template, request, redirect, url_for, session,get_flashed_messages
import tkinter
from tkinter import *
import sqlite3
import os
import email
from email.message import EmailMessage
import ssl
import smtplib
from tkinter import messagebox

def create_table():
    con = sqlite3.connect('database.db')
    cur = con.cursor()
    cur.execute("""
        CREATE TABLE IF NOT EXISTS users (
            username text,
            email text,
            password text
        )
    """)
    con.commit()
    con.close()

def register_user_to_db(username, email, password):
    con = sqlite3.connect('database.db')
    cur = con.cursor()
    cur.execute('INSERT INTO users(username,email,password) values (?,?,?)', (username, email, password))
    con.commit()
    con.close()

def check_user(email, password):
    con = sqlite3.connect('database.db')
    cur = con.cursor()
    cur.execute('Select email,password FROM users WHERE email=? and password=?', (email, password))

    result = cur.fetchone()
    if result:
        return True
    else:
        return False

app = Flask(__name__)
app.secret_key = "r@nd0mSk_1"

create_table()  # Create the users table when the app starts

@app.route("/")
def index():
    return render_template('login.html')

@app.route('/register', methods=["POST", "GET"])
def register():
    if request.method == 'POST':
        username = request.form['username']
        email = request.form['email']
        password = request.form['password']

        register_user_to_db(username, email, password)
        return redirect(url_for('index'))

    else:
        return render_template('register.html')

@app.route('/login', methods=["POST", "GET"])
def login():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']
        print(check_user(email, password))
        if check_user(email, password):
            session['email'] = email

        return redirect(url_for('home'))
    else:
        return redirect(url_for('index'))

@app.route('/home', methods=['POST', "GET"])
def home():
    if 'email' in session:
        return render_template('home.html', username=session['email'])
    else:
        return "Email or Password is wrong!"

@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('index'))

@app.route("/About Us/")
def aboutUs():
    return render_template("about.html")


@app.route("/Services/")
def services():
    return render_template("service.html")


@app.route("/Vacination Schedule/")
def schedule():
    return render_template("schedule.html")

@app.route("/sheduling/", methods=["POST"])
def registering():
    global childname
    childname = request.form['patientname']
    global parentname
    parentname = request.form['Parent']
    global appointmentdate
    appointmentdate = request.form['appointment-date']
    global dob
    dob = request.form['dob']
    global childage
    childage = request.form['Age']
    global selectedVaccine
    selectedVaccine = request.form['vaccine']
    global selectedSlot
    selectedSlot = request.form['slot']
    global selectedDoctor
    selectedDoctor = request.form['centre']
    global phoneNo
    phoneNo = request.form['phone-no']
    global emailadd
    emailadd = request.form['em']
    return render_template('paymentconfirmation.html')

@app.route("/Resources/")
def resources():
    return render_template("resources.html")


@app.route("/Doctors/")
def doctors():
    return render_template("doctor.html")


@app.route("/Contact Us/")
def contactUs():
    return render_template("contact.html")


@app.route("/successful payment/")
def successfulPayment():
    print(childname)
    print(parentname)
    print(appointmentdate)
    print(dob)
    print(childage)
    print(selectedVaccine)
    print(selectedSlot)
    print(selectedDoctor)
    print(phoneNo)

    database_connection = sqlite3.connect("Vaccination.db")
    database_cursor = database_connection.cursor()

    executing = "insert into Registration (PatientName,ParentName,AppointmentDate,DateofBirth,ChildAge,Vaccine,Slot,Doctor,MobileNumber,Email) values ('"+childname+"','"+parentname+"','"+appointmentdate+"','"+dob+"',"+childage+",'"+selectedVaccine+"','"+selectedSlot+"','"+selectedDoctor+"',"+phoneNo+",'"+emailadd+"');"
    
    print(executing)
    try:
        print("Enter into the try")
        database_cursor.execute(executing)
        database_connection.commit()
        database_connection.close()
    except:
        print("Bad Luck! Not Able to add Data in the database")


    email_reciever = emailadd
    try:

        email_sender = 'pasifista29@gmail.com'
        email_password = 'gkrfnvmwpouvjbwh'

        print(email_reciever)

        subject = 'Booking Confirmation'
        body = """
            Welcome! """+parentname+""",
            To our vacination center 
            Your child """ +childname+ """'s vaccination slot
            on """ +appointmentdate+""" has been confirmed.
            Please show this email at reception on the day of 
            appointment
            """

        em = EmailMessage()
        em['From'] = email_sender
        em['To'] = email_reciever
        em['subject'] = subject
        em.set_content(body)

        context = ssl.create_default_context()

        with smtplib.SMTP_SSL('smtp.gmail.com',465,context=context) as smtp:
            smtp.login(email_sender, email_password)
            smtp.sendmail(email_sender, email_reciever, em.as_string())

    except:
        print(email_reciever)
        print("incorrect automation")
    return render_template("thanku.html")


if __name__=="__main__":
    app.run(debug=True,port=7000)

if __name__ == '__main__':
    app.run(debug=True)







# import sqlite3
# from flask import Flask, render_template, request, redirect, url_for, session, flash

# app = Flask(__name__)
# app.secret_key = "r@nd0mSk_1"

# # Create the users table
# def create_table():
#     con = sqlite3.connect('database.db')
#     cur = con.cursor()
#     cur.execute("""
#         CREATE TABLE IF NOT EXISTS users (
#             username text,
#             email text PRIMARY KEY,
#             password text
#         )
#     """)
#     con.commit()
#     con.close()

# # Register user to the database
# def register_user_to_db(username, email, password):
#     con = sqlite3.connect('database.db')
#     cur = con.cursor()
#     cur.execute('INSERT INTO users(username,email,password) VALUES (?, ?, ?)', (username, email, password))
#     con.commit()
#     con.close()

# # Check if the user exists in the database
# def check_user(email, password):
#     con = sqlite3.connect('database.db')
#     cur = con.cursor()
#     cur.execute('SELECT email, password FROM users WHERE email=? AND password=?', (email, password))
#     result = cur.fetchone()
#     con.close()
#     return result is not None

# # Initialize the database
# create_table()

# @app.route("/")
# def index():
#     return render_template('login.html')

# @app.route('/register', methods=["POST", "GET"])
# def register():
#     if request.method == 'POST':
#         username = request.form['username']
#         email = request.form['email']
#         password = request.form['password']
        
#         # Check if user already exists
#         con = sqlite3.connect('database.db')
#         cur = con.cursor()
#         cur.execute('SELECT * FROM users WHERE email = ?', (email,))
#         user_exists = cur.fetchone()
#         con.close()

#         if user_exists:
#             flash('Email already registered. Please log in.', 'error')
#             return redirect(url_for('index'))
#         else:
#             register_user_to_db(username, email, password)
#             flash('Registration successful! You can now log in.', 'success')
#             return redirect(url_for('index'))
#     else:
#         return render_template('register.html')

# @app.route('/login', methods=["POST", "GET"])
# def login():
#     if request.method == 'POST':
#         email = request.form['email']
#         password = request.form['password']
        
#         if check_user(email, password):
#             session['email'] = email
#             flash('Login successful!', 'success')
#             return redirect(url_for('home'))
#         else:
#             flash('Invalid email or password. Please try again or register first.', 'error')
#             return redirect(url_for('index'))
#     else:
#         return redirect(url_for('index'))

# @app.route('/home', methods=['POST', "GET"])
# def home():
#     if 'email' in session:
#         return render_template('home.html', username=session['email'])
#     else:
#         flash('You are not logged in. Please log in first.', 'error')
#         return redirect(url_for('index'))

# @app.route('/logout')
# def logout():
#     session.clear()
#     flash('You have been logged out.', 'success')
#     return redirect(url_for('index'))

# @app.route("/About Us/")
# def aboutUs():
#     return render_template("about.html")

# @app.route("/Services/")
# def services():
#     return render_template("service.html")

# @app.route("/Vacination Schedule/")
# def schedule():
#     return render_template("schedule.html")

# @app.route("/sheduling/", methods=["POST"])
# def registering():
#     global childname
#     childname = request.form['patientname']
#     global parentname
#     parentname = request.form['Parent']
#     global appointmentdate
#     appointmentdate = request.form['appointment-date']
#     global dob
#     dob = request.form['dob']
#     global childage
#     childage = request.form['Age']
#     global selectedVaccine
#     selectedVaccine = request.form['vaccine']
#     global selectedSlot
#     selectedSlot = request.form['slot']
#     global selectedDoctor
#     selectedDoctor = request.form['centre']
#     global phoneNo
#     phoneNo = request.form['phone-no']
#     global emailadd
#     emailadd = request.form['em']
#     return render_template('paymentconfirmation.html')

# @app.route("/Resources/")
# def resources():
#     return render_template("resources.html")

# @app.route("/Doctors/")
# def doctors():
#     return render_template("doctor.html")

# @app.route("/Contact Us/")
# def contactUs():
#     return render_template("contact.html")

# @app.route("/successful payment/")
# def successfulPayment():
#     print(childname)
#     print(parentname)
#     print(appointmentdate)
#     print(dob)
#     print(childage)
#     print(selectedVaccine)
#     print(selectedSlot)
#     print(selectedDoctor)
#     print(phoneNo)

#     database_connection = sqlite3.connect("Vaccination.db")
#     database_cursor = database_connection.cursor()

#     executing = "INSERT INTO Registration (PatientName,ParentName,AppointmentDate,DateofBirth,ChildAge,Vaccine,Slot,Doctor,MobileNumber,Email) values ('"+childname+"','"+parentname+"','"+appointmentdate+"','"+dob+"',"+childage+",'"+selectedVaccine+"','"+selectedSlot+"','"+selectedDoctor+"',"+phoneNo+",'"+emailadd+"');"
    
#     print(executing)
#     try:
#         print("Enter into the try")
#         database_cursor.execute(executing)
#         database_connection.commit()
#         database_connection.close()
#     except:
#         print("Bad Luck! Not Able to add Data in the database")

#     email_reciever = emailadd
#     try:
#         email_sender = 'pasifista29@gmail.com'
#         email_password = 'gkrfnvmwpouvjbwh'
#         subject = 'Booking Confirmation'
#         body = f"""
#             Welcome, {parentname},
#             Your child {childname}'s vaccination slot on {appointmentdate} has been confirmed.
#             Please show this email at reception on the day of the appointment.
#         """

#         em = EmailMessage()
#         em['From'] = email_sender
#         em['To'] = email_reciever
#         em['subject'] = subject
#         em.set_content(body)

#         context = ssl.create_default_context()

#         with smtplib.SMTP_SSL('smtp.gmail.com', 465, context=context) as smtp:
#             smtp.login(email_sender, email_password)
#             smtp.sendmail(email_sender, email_reciever, em.as_string())
#     except:
#         print(email_reciever)
#         print("Failed to send email confirmation.")
#     return render_template("thanku.html")

# if __name__=="__main__":
#     app.run(debug=True, port=7000)





